﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ch2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            do
            {
                int j = 1;
                do
                {
                    Console.Write("{0}*{1}={2}\t", i, j, i * j);
                    j++;
                }
                while (j < 10);
                Console.Write("\n");
                i++;
            }
            while (i<10);

        }
    }
}
